-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.15.0.7171
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table m-account.buyer
CREATE TABLE IF NOT EXISTS `buyer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_name` varchar(50) NOT NULL,
  `buyer_code` varchar(20) DEFAULT NULL,
  `buyer_status` enum('REG','EXP') DEFAULT 'REG',
  `buyer_address` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 aktif 1 nonaktif',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.buyer: ~12 rows (approximately)
INSERT INTO `buyer` (`id`, `buyer_name`, `buyer_code`, `buyer_status`, `buyer_address`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'Expense Buyer', '99xx', 'EXP', 'Ceres', 0, '2026-05-08 08:50:37', '2026-05-08 08:51:02'),
	(2, 'test', '12345', 'REG', 'TI', 0, '2026-04-15 09:48:13', '2026-05-08 08:49:03'),
	(3, 'test 2', '123445', '', NULL, 1, '2026-04-15 09:48:34', '2026-04-15 09:48:40'),
	(4, 'test 3', '123445', '', NULL, 1, '2026-04-15 09:48:48', '2026-04-15 11:11:16'),
	(5, 'coba', '54321', 'REG', 'ADA', 0, '2026-04-15 11:27:19', '2026-05-08 08:48:55'),
	(6, 'Warga RT2', 'BS01', 'REG', 'jalan apa RT2', 0, '2026-04-15 15:03:22', '2026-05-08 08:48:34'),
	(7, 'Budi', '100000', '', NULL, 1, '2026-04-16 15:17:55', '2026-04-16 15:18:16'),
	(8, 'Budi', '100', '', NULL, 1, '2026-04-16 15:19:35', '2026-04-16 15:19:39'),
	(9, 'budi', '1000000', 'REG', 'IT', 0, '2026-04-23 13:29:07', '2026-05-08 08:48:07'),
	(10, 'test', 'test', '', NULL, 1, '2026-04-23 14:27:10', '2026-04-23 14:27:34'),
	(11, 'Upload baru', '1234567', 'REG', 'test', 0, '2026-05-07 16:45:55', '2026-05-08 08:47:44'),
	(12, 'admin', '123456', 'EXP', 'IT', 0, '2026-04-15 09:04:57', '2026-05-08 09:13:52'),
	(14, 'Mr Enjang Sobana', '10000956', 'REG', 'MAINTENANCE', 0, '2026-05-08 08:51:52', '2026-05-08 08:51:52'),
	(15, 'Agus', '1000001', 'REG', 'CHOCOBAR', 0, '2026-05-08 08:57:01', '2026-05-08 08:57:01');

-- Dumping structure for table m-account.item_transactions
CREATE TABLE IF NOT EXISTS `item_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `warehouse` enum('1','2') NOT NULL,
  `transaction_date` date NOT NULL DEFAULT curdate(),
  `type` enum('IN','OUT') NOT NULL,
  `qty` int(11) NOT NULL,
  `reference_no` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item_warehouse` (`item_id`,`warehouse`),
  KEY `idx_ref` (`reference_no`),
  KEY `idx_date` (`transaction_date`) USING BTREE,
  CONSTRAINT `FK_item_transactions_items` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.item_transactions: ~30 rows (approximately)
INSERT INTO `item_transactions` (`id`, `item_id`, `warehouse`, `transaction_date`, `type`, `qty`, `reference_no`, `notes`, `created_at`) VALUES
	(1, 1, '1', '2026-04-06', 'IN', 100, 'in-01', 'Penerimaan Barang Baru', '2026-04-30 10:04:44'),
	(2, 4, '1', '2026-04-13', 'IN', 75, 'in-02', 'Penerimaan Barang Baru', '2026-04-30 10:07:59'),
	(3, 3, '1', '2026-04-13', 'IN', 100, 'in-02', 'Penerimaan Barang Baru', '2026-04-30 10:07:59'),
	(4, 2, '2', '2026-04-20', 'IN', 80, 'in-03', 'Penerimaan Barang Baru', '2026-04-30 10:09:34'),
	(5, 5, '2', '2026-04-20', 'IN', 60, 'in-03', 'Penerimaan Barang Baru', '2026-04-30 10:09:34'),
	(6, 4, '1', '2026-04-08', 'OUT', 5, 'SLS - 1', 'Penjualan POS', '2026-04-30 10:10:53'),
	(7, 3, '1', '2026-04-08', 'OUT', 10, 'SLS - 1', 'Penjualan POS', '2026-04-30 10:10:53'),
	(8, 4, '1', '2026-04-15', 'OUT', 3, 'SLS - 2', 'Penjualan POS', '2026-04-30 10:13:28'),
	(9, 3, '1', '2026-04-15', 'OUT', 2, 'SLS - 2', 'Penjualan POS', '2026-04-30 10:13:28'),
	(10, 1, '1', '2026-04-15', 'OUT', 1, 'SLS - 2', 'Penjualan POS', '2026-04-30 10:13:28'),
	(11, 4, '1', '2026-04-27', 'OUT', 3, 'SLS - 3', 'Penjualan POS', '2026-04-30 14:21:54'),
	(12, 3, '1', '2026-04-27', 'OUT', 3, 'SLS - 3', 'Penjualan POS', '2026-04-30 14:21:54'),
	(13, 1, '1', '2026-04-27', 'OUT', 3, 'SLS - 3', 'Penjualan POS', '2026-04-30 14:21:54'),
	(14, 4, '1', '2026-05-05', 'OUT', 4, 'SLS - 4', 'Penjualan POS', '2026-05-05 08:29:45'),
	(15, 1, '1', '2026-05-05', 'OUT', 1, 'SLS - 4', 'Penjualan POS', '2026-05-05 08:29:45'),
	(16, 1, '1', '2026-05-06', 'OUT', 15, 'SLS - 5', 'Penjualan POS', '2026-05-06 14:59:17'),
	(17, 3, '1', '2026-05-06', 'OUT', 5, 'EXP - 1', 'Penjualan POS', '2026-05-06 16:14:10'),
	(18, 4, '1', '2026-05-06', 'OUT', 5, 'EXP - 2', 'Penjualan POS', '2026-05-06 16:19:43'),
	(19, 4, '1', '2026-05-06', 'OUT', 1, 'SLS - 6', 'Penjualan POS', '2026-05-06 16:48:41'),
	(20, 4, '1', '2026-05-07', 'OUT', 1, 'SLS - 7', 'Penjualan POS', '2026-05-07 08:07:55'),
	(21, 4, '1', '2026-05-04', 'OUT', 1, 'SLS - 8', 'Penjualan POS', '2026-05-07 08:08:21'),
	(22, 5, '2', '2026-05-04', 'OUT', 10, 'SLS - 9', 'Penjualan POS', '2026-05-07 08:11:03'),
	(23, 4, '1', '2026-05-01', 'OUT', 2, 'SLS - 10', 'Penjualan BS SLS - 10', '2026-05-07 08:25:39'),
	(24, 2, '2', '2026-05-07', 'OUT', 5, 'SLS - 11', 'Penjualan BS - SLS - 11', '2026-05-07 10:47:42'),
	(25, 1, '1', '2026-05-07', 'OUT', 5, 'SLS - 12', 'Penjualan BS - SLS - 12', '2026-05-07 14:20:12'),
	(26, 3, '1', '2026-05-07', 'OUT', 5, 'SLS - 12', 'Penjualan BS - SLS - 12', '2026-05-07 14:20:12'),
	(27, 4, '1', '2026-05-07', 'OUT', 1, 'SLS - 12', 'Penjualan BS - SLS - 12', '2026-05-07 14:20:12'),
	(28, 2, '2', '2026-05-07', 'OUT', 4, 'SLS - 13', 'Penjualan BS - SLS - 13', '2026-05-07 14:21:04'),
	(29, 3, '1', '2026-05-08', 'OUT', 5, 'EXP - 3', 'Penjualan BS - EXP - 3', '2026-05-08 09:11:30'),
	(30, 9, '2', '2026-05-08', 'IN', 5, 'BW-1', 'Penerimaan Baru - BW-1', '2026-05-08 09:15:12'),
	(31, 12, '2', '2026-05-08', 'IN', 10, 'BW01', 'Penerimaan Baru - BW01', '2026-05-08 10:32:04'),
	(32, 12, '2', '2026-05-08', 'OUT', 2, 'SLS - 14', 'Penjualan BS - SLS - 14', '2026-05-08 10:43:48'),
	(33, 12, '2', '2026-05-08', 'OUT', 8, 'SLS - 15', 'Penjualan BS - SLS - 15', '2026-05-08 10:45:16');

-- Dumping structure for table m-account.items
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) NOT NULL DEFAULT '',
  `item_name` varchar(200) NOT NULL,
  `category` enum('1','2') NOT NULL COMMENT '1: ByProd, 2: Sampah',
  `item_uom` varchar(20) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `unit_cost` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 aktif 1 nonaktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_id` (`item_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.items: ~9 rows (approximately)
INSERT INTO `items` (`id`, `item_code`, `item_name`, `category`, `item_uom`, `unit_price`, `unit_cost`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'ITM-001', 'wafer', '1', 'Kg', 25000, 25000, 0, '2026-03-30 02:27:10', '2026-04-23 05:28:31'),
	(2, 'ITM-002', 'kacang gosong', '2', 'Kg', 10000, 10000, 0, '2026-03-30 02:27:10', '2026-04-16 07:26:19'),
	(3, 'ITM-003', 'kacang', '1', 'Zak', 20000, 20000, 0, '2026-03-30 02:27:10', '2026-04-02 01:45:48'),
	(4, 'ITM-004', 'Choco', '1', 'Box', 35000, 35000, 0, '2026-03-30 03:23:56', '2026-04-23 05:28:51'),
	(5, 'ITM-005', 'test', '2', 'Pcs', 15000, 15000, 0, '2026-03-30 05:38:37', '2026-04-06 08:23:26'),
	(7, 'ITM-006', 'baru dari  react', '1', 'Kg', 10000, 10000, 0, '2026-04-06 02:24:23', '2026-04-16 07:46:09'),
	(8, 'test 2', 'test 2', '2', 'Kg', 1000, 1000, 1, '2026-04-16 07:40:26', '2026-04-16 07:48:08'),
	(9, 'PC', 'Laptop', '1', 'Unit', 1000000, 0, 0, '2026-04-20 09:22:28', '2026-05-08 02:15:31'),
	(11, 'C123456', 'UPLOAD', '1', 'Kg', 10000, 0, 0, '2026-05-07 10:00:03', '2026-05-07 10:00:40'),
	(12, 'C001', 'monitor', '2', 'unit', 1000000, 0, 0, '2026-05-08 03:31:23', '2026-05-08 03:31:23');

-- Dumping structure for table m-account.receivement
CREATE TABLE IF NOT EXISTS `receivement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_number` varchar(20) NOT NULL,
  `warehouse` enum('1','2') NOT NULL COMMENT '1:gudang BS 2:gudang sampah',
  `received_by` varchar(50) NOT NULL,
  `date_receive` date NOT NULL,
  `notes` varchar(200) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.receivement: ~3 rows (approximately)
INSERT INTO `receivement` (`id`, `doc_number`, `warehouse`, `received_by`, `date_receive`, `notes`, `status`, `created_at`, `updated_at`) VALUES
	(20, 'in-01', '1', 'test', '2026-04-06', '', '0', '2026-04-30 10:04:44', '2026-04-30 10:04:44'),
	(21, 'in-02', '1', 'test', '2026-04-13', '', '0', '2026-04-30 10:07:59', '2026-04-30 10:07:59'),
	(22, 'in-03', '2', 'test', '2026-04-20', '', '0', '2026-04-30 10:09:34', '2026-04-30 10:10:05'),
	(23, 'BW-1', '2', 'jaja', '2026-05-08', '', '0', '2026-05-08 09:15:12', '2026-05-08 09:15:12'),
	(24, 'BW01', '2', 'Cecep', '2026-05-08', '', '0', '2026-05-08 10:32:04', '2026-05-08 10:32:04');

-- Dumping structure for table m-account.receivement_detail
CREATE TABLE IF NOT EXISTS `receivement_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receive_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_receivement_detail_items` (`item_id`),
  KEY `receive_id` (`receive_id`),
  CONSTRAINT `FK_receivement_detail_items` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `FK_receivement_detail_receivement` FOREIGN KEY (`receive_id`) REFERENCES `receivement` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.receivement_detail: ~5 rows (approximately)
INSERT INTO `receivement_detail` (`id`, `receive_id`, `item_id`, `item_qty`) VALUES
	(44, 20, 1, 100),
	(45, 21, 4, 75),
	(46, 21, 3, 100),
	(47, 22, 2, 80),
	(48, 22, 5, 60),
	(49, 23, 9, 5),
	(50, 24, 12, 10);

-- Dumping structure for table m-account.sales
CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_type` enum('SLS','EXP') NOT NULL DEFAULT 'SLS',
  `invoice_no` varchar(20) NOT NULL,
  `buyer` int(11) NOT NULL,
  `warehouse` enum('1','2') NOT NULL COMMENT '1:gudang BS 2:gudang sampah',
  `sales_date` date NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `buyer` (`buyer`),
  CONSTRAINT `FK_sales_buyer` FOREIGN KEY (`buyer`) REFERENCES `buyer` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.sales: ~11 rows (approximately)
INSERT INTO `sales` (`id`, `sale_type`, `invoice_no`, `buyer`, `warehouse`, `sales_date`, `status`, `created_at`, `updated_at`) VALUES
	(62, 'SLS', 'SLS - 1', 12, '1', '2026-04-08', '0', '2026-04-30 10:10:53', '2026-04-30 10:10:53'),
	(63, 'SLS', 'SLS - 2', 5, '1', '2026-04-15', '0', '2026-04-30 10:13:28', '2026-04-30 10:13:28'),
	(64, 'SLS', 'SLS - 3', 9, '1', '2026-04-27', '0', '2026-04-30 14:21:54', '2026-04-30 14:21:54'),
	(65, 'SLS', 'SLS - 4', 12, '1', '2026-05-05', '0', '2026-05-05 08:29:45', '2026-05-05 08:29:45'),
	(66, 'EXP', 'SLS - 5', 9, '1', '2026-05-06', '0', '2026-05-06 14:59:17', '2026-05-06 14:59:17'),
	(67, 'EXP', 'EXP - 1', 9, '1', '2026-05-06', '0', '2026-05-06 16:14:10', '2026-05-06 16:14:10'),
	(68, 'EXP', 'EXP - 2', 12, '1', '2026-05-06', '0', '2026-05-06 16:19:43', '2026-05-06 16:19:43'),
	(69, 'SLS', 'SLS - 6', 5, '1', '2026-05-06', '0', '2026-05-06 16:48:41', '2026-05-06 16:48:41'),
	(70, 'SLS', 'SLS - 7', 2, '1', '2026-05-07', '0', '2026-05-07 08:07:55', '2026-05-07 08:07:55'),
	(71, 'SLS', 'SLS - 8', 5, '1', '2026-05-04', '0', '2026-05-07 08:08:21', '2026-05-07 08:08:21'),
	(72, 'SLS', 'SLS - 9', 6, '2', '2026-05-04', '0', '2026-05-07 08:11:03', '2026-05-07 08:11:03'),
	(73, 'SLS', 'SLS - 10', 5, '1', '2026-05-01', '0', '2026-05-07 08:25:39', '2026-05-07 08:25:39'),
	(74, 'SLS', 'SLS - 11', 5, '2', '2026-05-07', '0', '2026-05-07 10:47:42', '2026-05-07 10:47:42'),
	(75, 'SLS', 'SLS - 12', 2, '1', '2026-05-07', '0', '2026-05-07 14:20:12', '2026-05-07 14:20:12'),
	(76, 'SLS', 'SLS - 13', 12, '2', '2026-05-07', '0', '2026-05-07 14:21:04', '2026-05-07 14:21:04'),
	(77, 'EXP', 'EXP - 3', 1, '1', '2026-05-08', '0', '2026-05-08 09:11:30', '2026-05-08 09:11:30'),
	(78, 'SLS', 'SLS - 14', 6, '2', '2026-05-08', '0', '2026-05-08 10:43:48', '2026-05-08 10:43:48'),
	(79, 'SLS', 'SLS - 15', 2, '2', '2026-05-08', '0', '2026-05-08 10:45:16', '2026-05-08 10:45:16');

-- Dumping structure for table m-account.sales_detail
CREATE TABLE IF NOT EXISTS `sales_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `sales_detail_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_detail_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table m-account.sales_detail: ~22 rows (approximately)
INSERT INTO `sales_detail` (`id`, `sale_id`, `item_id`, `item_qty`) VALUES
	(57, 62, 4, 5),
	(58, 62, 3, 10),
	(59, 63, 4, 3),
	(60, 63, 3, 2),
	(61, 63, 1, 1),
	(62, 64, 4, 3),
	(63, 64, 3, 3),
	(64, 64, 1, 3),
	(65, 65, 4, 4),
	(66, 65, 1, 1),
	(67, 66, 1, 15),
	(68, 67, 3, 5),
	(69, 68, 4, 5),
	(70, 69, 4, 1),
	(71, 70, 4, 1),
	(72, 71, 4, 1),
	(73, 72, 5, 10),
	(74, 73, 4, 2),
	(75, 74, 2, 5),
	(76, 75, 1, 5),
	(77, 75, 3, 5),
	(78, 75, 4, 1),
	(79, 76, 2, 4),
	(80, 77, 3, 5),
	(81, 78, 12, 2),
	(82, 79, 12, 8);

-- Dumping structure for table m-account.stock_closing
CREATE TABLE IF NOT EXISTS `stock_closing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `warehouse` enum('1','2') NOT NULL DEFAULT '1',
  `item_id` int(11) NOT NULL DEFAULT 0,
  `qty_open` int(11) NOT NULL DEFAULT 0,
  `qty_close` int(11) NOT NULL DEFAULT 0,
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `FK_stock_closing_items` (`item_id`),
  CONSTRAINT `FK_stock_closing_items` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.stock_closing: ~11 rows (approximately)
INSERT INTO `stock_closing` (`id`, `date`, `warehouse`, `item_id`, `qty_open`, `qty_close`, `updated_date`) VALUES
	(67, '2026-04-30', '1', 4, 0, 64, '2026-05-08 02:14:22'),
	(68, '2026-04-30', '1', 3, 0, 85, '2026-05-08 02:14:22'),
	(69, '2026-04-30', '2', 2, 0, 80, '2026-05-08 02:14:22'),
	(70, '2026-04-30', '2', 5, 0, 60, '2026-05-08 02:14:22'),
	(71, '2026-04-30', '1', 1, 0, 96, '2026-05-08 02:14:22'),
	(72, '2026-05-31', '1', 4, 64, 49, '2026-05-08 02:15:47'),
	(73, '2026-05-31', '1', 3, 85, 70, '2026-05-08 02:15:47'),
	(74, '2026-05-31', '2', 2, 80, 71, '2026-05-08 02:15:47'),
	(75, '2026-05-31', '2', 9, 0, 5, '2026-05-08 02:15:47'),
	(76, '2026-05-31', '2', 5, 60, 50, '2026-05-08 02:15:47'),
	(77, '2026-05-31', '1', 1, 96, 75, '2026-05-08 02:15:47');

-- Dumping structure for table m-account.stocks
CREATE TABLE IF NOT EXISTS `stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `warehouse` enum('1','2') NOT NULL DEFAULT '1',
  `date` date NOT NULL,
  `qty_open` int(11) NOT NULL DEFAULT 0,
  `qty_in` int(11) NOT NULL DEFAULT 0,
  `qty_out` int(11) NOT NULL DEFAULT 0,
  `qty_total` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `FK_stocks_items` (`item_id`),
  CONSTRAINT `FK_stocks_items` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table m-account.stocks: ~27 rows (approximately)
INSERT INTO `stocks` (`id`, `item_id`, `warehouse`, `date`, `qty_open`, `qty_in`, `qty_out`, `qty_total`, `created_at`, `updated_at`) VALUES
	(1, 1, '1', '2026-04-30', 0, 100, 0, 100, '2026-04-30 10:04:44', '2026-04-30 10:04:44'),
	(2, 4, '1', '2026-04-30', 0, 75, 0, 75, '2026-04-30 10:07:59', '2026-04-30 10:07:59'),
	(3, 3, '1', '2026-04-30', 0, 100, 0, 100, '2026-04-30 10:07:59', '2026-04-30 10:07:59'),
	(4, 2, '2', '2026-04-30', 0, 80, 0, 80, '2026-04-30 10:09:34', '2026-04-30 10:09:34'),
	(5, 5, '2', '2026-04-30', 0, 60, 0, 60, '2026-04-30 10:09:34', '2026-04-30 10:09:34'),
	(6, 4, '1', '2026-04-30', 75, 0, 5, 70, '2026-04-30 10:10:53', '2026-04-30 10:10:53'),
	(7, 3, '1', '2026-04-30', 100, 0, 10, 90, '2026-04-30 10:10:53', '2026-04-30 10:10:53'),
	(8, 4, '1', '2026-04-30', 70, 0, 3, 67, '2026-04-30 10:13:28', '2026-04-30 10:13:28'),
	(9, 3, '1', '2026-04-30', 90, 0, 2, 88, '2026-04-30 10:13:28', '2026-04-30 10:13:28'),
	(10, 1, '1', '2026-04-30', 100, 0, 1, 99, '2026-04-30 10:13:28', '2026-04-30 10:13:28'),
	(11, 4, '1', '2026-04-30', 67, 0, 3, 64, '2026-04-30 14:21:54', '2026-04-30 14:21:54'),
	(12, 3, '1', '2026-04-30', 88, 0, 3, 85, '2026-04-30 14:21:54', '2026-04-30 14:21:54'),
	(13, 1, '1', '2026-04-30', 99, 0, 3, 96, '2026-04-30 14:21:54', '2026-04-30 14:21:54'),
	(14, 4, '1', '2026-05-05', 64, 0, 4, 60, '2026-05-05 08:29:45', '2026-05-05 08:29:45'),
	(15, 1, '1', '2026-05-05', 96, 0, 1, 95, '2026-05-05 08:29:45', '2026-05-05 08:29:45'),
	(16, 1, '1', '2026-05-06', 95, 0, 15, 80, '2026-05-06 14:59:17', '2026-05-06 14:59:17'),
	(17, 3, '1', '2026-05-06', 85, 0, 5, 80, '2026-05-06 16:14:10', '2026-05-06 16:14:10'),
	(18, 4, '1', '2026-05-06', 60, 0, 5, 55, '2026-05-06 16:19:43', '2026-05-06 16:19:43'),
	(19, 4, '1', '2026-05-06', 55, 0, 1, 54, '2026-05-06 16:48:41', '2026-05-06 16:48:41'),
	(20, 4, '1', '2026-05-07', 54, 0, 1, 53, '2026-05-07 08:07:55', '2026-05-07 08:07:55'),
	(21, 4, '1', '2026-05-07', 53, 0, 1, 52, '2026-05-07 08:08:21', '2026-05-07 08:08:21'),
	(22, 5, '2', '2026-05-07', 60, 0, 10, 50, '2026-05-07 08:11:03', '2026-05-07 08:11:03'),
	(23, 4, '1', '2026-05-07', 52, 0, 2, 50, '2026-05-07 08:25:39', '2026-05-07 08:25:39'),
	(24, 2, '2', '2026-05-07', 80, 0, 5, 75, '2026-05-07 10:47:42', '2026-05-07 10:47:42'),
	(25, 1, '1', '2026-05-07', 80, 0, 5, 75, '2026-05-07 14:20:12', '2026-05-07 14:20:12'),
	(26, 3, '1', '2026-05-07', 80, 0, 5, 75, '2026-05-07 14:20:12', '2026-05-07 14:20:12'),
	(27, 4, '1', '2026-05-07', 50, 0, 1, 49, '2026-05-07 14:20:12', '2026-05-07 14:20:12'),
	(28, 2, '2', '2026-05-07', 75, 0, 4, 71, '2026-05-07 14:21:04', '2026-05-07 14:21:04'),
	(29, 3, '1', '2026-05-08', 75, 0, 5, 70, '2026-05-08 09:11:30', '2026-05-08 09:11:30'),
	(30, 9, '2', '2026-05-08', 0, 5, 0, 5, '2026-05-08 09:15:12', '2026-05-08 09:15:12'),
	(31, 12, '2', '2026-05-08', 0, 10, 0, 10, '2026-05-08 10:32:04', '2026-05-08 10:32:04'),
	(32, 12, '2', '2026-05-08', 10, 0, 2, 8, '2026-05-08 10:43:48', '2026-05-08 10:43:48'),
	(33, 12, '2', '2026-05-08', 8, 0, 8, 0, '2026-05-08 10:45:16', '2026-05-08 10:45:16');

-- Dumping structure for view m-account.vw_stock_report
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `vw_stock_report` (
	`warehouse` ENUM('1','2') NOT NULL COLLATE 'utf8mb4_general_ci',
	`periode` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`item_code` VARCHAR(1) NOT NULL COLLATE 'utf8mb4_general_ci',
	`item_name` VARCHAR(1) NOT NULL COLLATE 'utf8mb4_general_ci',
	`item_uom` VARCHAR(1) NOT NULL COLLATE 'utf8mb4_general_ci',
	`qty_open` INT(11) NOT NULL,
	`qty_in` DECIMAL(32,0) NULL,
	`qty_out` DECIMAL(32,0) NULL,
	`qty_close` INT(11) NOT NULL,
	`qty_onhand` DECIMAL(34,0) NULL,
	`selisih` DECIMAL(35,0) NULL
);

-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `vw_stock_report`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_stock_report` AS select `sc`.`warehouse` AS `warehouse`,date_format(`sc`.`date`,'%Y-%m') AS `periode`,`i`.`item_code` AS `item_code`,`i`.`item_name` AS `item_name`,`i`.`item_uom` AS `item_uom`,`sc`.`qty_open` AS `qty_open`,coalesce(`tr`.`total_in`,0) AS `qty_in`,coalesce(`tr`.`total_out`,0) AS `qty_out`,`sc`.`qty_close` AS `qty_close`,`sc`.`qty_open` + coalesce(`tr`.`total_in`,0) - coalesce(`tr`.`total_out`,0) AS `qty_onhand`,`sc`.`qty_close` - (`sc`.`qty_open` + coalesce(`tr`.`total_in`,0) - coalesce(`tr`.`total_out`,0)) AS `selisih` from ((`stock_closing` `sc` join `items` `i` on(`sc`.`item_id` = `i`.`id`)) left join (select `item_transactions`.`item_id` AS `item_id`,`item_transactions`.`warehouse` AS `warehouse`,date_format(`item_transactions`.`transaction_date`,'%Y-%m') AS `month_period`,sum(case when `item_transactions`.`type` = 'IN' then `item_transactions`.`qty` else 0 end) AS `total_in`,sum(case when `item_transactions`.`type` = 'OUT' then `item_transactions`.`qty` else 0 end) AS `total_out` from `item_transactions` group by `item_transactions`.`item_id`,`item_transactions`.`warehouse`,date_format(`item_transactions`.`transaction_date`,'%Y-%m')) `tr` on(`sc`.`item_id` = `tr`.`item_id` and `sc`.`warehouse` = `tr`.`warehouse` and date_format(`sc`.`date`,'%Y-%m') = `tr`.`month_period`))
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
